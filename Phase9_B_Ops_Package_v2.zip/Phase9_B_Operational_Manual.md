# Phase 9-B Operational Manual (Paper Trading)

**Objective:** Verify Operational Integrity & End-to-End Execution (Entry→Exit) in a real-time environment.  
**Success Criteria (Week 1):** Zero Crashes, Zero Heartbeat Gaps, 100% EOD Execution.

---

## 1) Daily Runbook (Strict Sequence)

**You must follow this order.** If you change the order, logs lose evidential value.

### A. Pre-flight Cleanup (Before 08:50)

1) Terminate stale engines (no `python.exe` running the engine).
2) Clean logs & data:

   ```powershell
   Remove-Item results/logs/* -Force
   Remove-Item GARAM_Data/realtime/* -Force
   ```

   *(Optional) archive old logs if needed*

### B. Launch Sequence (08:50 ~ 08:55)

1) Prepare Market Status (MA60):
   - Run feeder briefly or use a dedicated script to generate `GARAM_Data/market_status.csv`
   - **Check:** `ma60` column is not empty
2) Start Feeder (Atomic Mode):

   ```powershell
   python scripts/live/run_preflight_feeder.py  # (or Kiwoom feeder)
   ```

3) Start Engine (Engine V13):

   ```powershell
   python -m scripts.live.run_live_policy_v2_phase7
   ```

4) Console check:
   - **Confirm:** `[INFO] Loaded MA60 for N symbols (N > 300)`

### C. Health Check (First 60 Seconds)

1) Heartbeat: `results/logs/engine_heartbeat.csv`
   - New lines every 10 seconds
   - `lines_processed` increasing
2) Crash log: `results/logs/crash.log`
   - Must be 0 bytes or non-existent
3) Trace log: `results/logs/trace_*.csv`
   - Must exist and grow

---

## 2) Zero-Trade Diagnosis Rule

If **Trade Count = 0**, classify it using trace reasons.

| Symptom (trace reason) | Diagnosis | Ops Status | Action |
|---|---|---|---|
| NO_MA60 (dominant) | Startup sequence failure | **FAIL** | Generate `market_status.csv` first; restart in correct order |
| FEAT_FAIL (dominant) | Ingestion lag / data gaps / tolerance reject | **FAIL** | Check feeder + timestamps + tolerance |
| ROC_FAIL / VOL_FAIL | Market condition | **PASS** | Strategy working; no opportunities |
| TREND_FAIL | Trend filter blocking | **PASS** | MA60 filter working |
| COOLDOWN | Post-trade protection active | **PASS** | Normal |

**Quantitative FAIL thresholds (Week 1):**

- `NO_MA60` > **5%** after 09:10 ⇒ **FAIL**
- `FEAT_FAIL` > **10%** after 09:20 ⇒ **FAIL**

---

## 3) End-of-Day Checklist (15:30)

### EOD Execution (must be proven)

- **Log Evidence:** `[WARNING] EOD Force Close Triggered` exists (console / log file)
- **Data Evidence:** `trade_log_*.csv` shows flattening (no open positions) after 15:20, or EOD SELL entries exist

### Metric Integrity (P0 Gate)

- `engine_heartbeat.csv` shows `lines_processed` increased steadily
- **Gap Check:** No gaps > 30 seconds

### Clean Shutdown

- Engine exits gracefully at 15:30
- `crash.log` remains empty (0 bytes)

---

## 4) Emergency Procedures

### Crash Detected

1) Immediate stop
2) Copy `results/logs/crash.log`
3) Report with the exact timestamp and last 30 lines of console output

### Heartbeat Flatline

1) Validate feeder is alive
2) Restart feeder only first (engine may recover)
3) If still flat: restart engine with clean start sequence

---

## 5) Trace Slice Diagnosis (PowerShell)

**Purpose:** Diagnose “Zero Trade” days instantly (Market vs Operational Defect).

### 5.1 Extract Trace Slice (09:20~10:00) — Date Auto-Detect

```powershell
$trace = Get-ChildItem results/logs/trace_*.csv | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $trace) { throw "No trace_*.csv found in results/logs" }

$first = Import-Csv $trace.FullName | Select-Object -First 1
if (-not $first) { throw "Trace file exists but is empty" }

$dt0 = [datetime]$first.ts
$start = Get-Date ($dt0.ToString("yyyy-MM-dd") + " 09:20:00")
$end   = Get-Date ($dt0.ToString("yyyy-MM-dd") + " 10:00:00")

$out = "results/logs/trace_slice_0920_1000.csv"

Import-Csv $trace.FullName | ForEach-Object { $_.ts = [datetime]$_.ts; $_ } |
  Where-Object { $_.ts -ge $start -and $_.ts -lt $end } |
  Export-Csv $out -NoTypeInformation -Encoding UTF8

"TRACE_SRC = $($trace.FullName)"
"WINDOW    = $start ~ $end"
"SLICE_OUT = $out"
```

### 5.2 View Reason Distribution (Top 15)

```powershell
Import-Csv results/logs/trace_slice_0920_1000.csv |
  Group-Object reason |
  Sort-Object Count -Descending |
  Select-Object -First 15 |
  Format-Table Count, Name -AutoSize
```

### Judgment Criteria

- **PASS:** `ROC_FAIL`, `VOL_FAIL`, `TREND_FAIL`, `COOLDOWN` dominant
- **FAIL:**
  - `NO_MA60` > 5% (Check Market Status / Startup Order)
  - `FEAT_FAIL` > 10% (Check Feeder Quality)

---

## 6. Automatic Daily Reporting (Recommended)

**Purpose:** Generate a markdown report populated with heartbeat, crash, and trace stats in 1 click.

```powershell
# Run from Project Root
.\scripts\ops\generate_daily_report.ps1
```

Result: `results/reports/Daily_Report_YYYY-MM-DD.md`

---

## 7. EOD Mode Behavior (Operational Safety Note)

After **15:20**, the engine must:

- **Block new entries**
- **Continue position management / exits**
- **Force-close once** (idempotent)

This prevents “zombie positions” if exits require retries in a live integration.
