# Generate Phase 9-B Daily Report
# Usage: ./generate_daily_report.ps1

$root = (Resolve-Path "$PSScriptRoot\..\..").Path
$logDir = "$root\results\logs"
$reportDate = Get-Date -Format "yyyy-MM-dd"
$outputFile = "$root\results\reports\Daily_Report_$reportDate.md"

if (-not (Test-Path "$root\results\reports")) {
    New-Item -ItemType Directory -Force -Path "$root\results\reports" | Out-Null
}

$sb = [System.Text.StringBuilder]::new()
[void]$sb.AppendLine("# Phase 9-B Daily Operation Report")
[void]$sb.AppendLine("**Date:** $reportDate")
[void]$sb.AppendLine("**Operator:** Auto-Generated")
[void]$sb.AppendLine("")

# 1. Operational Integrity
[void]$sb.AppendLine("## 1. Operational Integrity (Gate Check)")
[void]$sb.AppendLine("| Gate | Metric | Status | Evidence |")
[void]$sb.AppendLine("| :--- | :--- | :--- | :--- |")

# P0: Heartbeat
$hbFile = "$logDir\engine_heartbeat.csv"
$hbStatus = "NOK"
$hbEvid = "Missing"
if (Test-Path $hbFile) {
    $hbLines = Get-Content $hbFile
    if ($hbLines.Count -gt 10) { 
        $hbStatus = "OK" 
        $hbEvid = "Active ($($hbLines.Count) lines)"
    }
    else {
        $hbEvid = "Too few lines"
    }
}
[void]$sb.AppendLine("| **P0: Ingestion** | Heartbeat | $hbStatus | $hbEvid |")

# P1: Trace
$traceFile = Get-ChildItem "$logDir\trace_*.csv" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
$traceStatus = "NOK"
$traceEvid = "Missing"
if ($traceFile) {
    if ($traceFile.Length -gt 100) {
        $traceStatus = "OK"
        $traceEvid = "Exists ($($traceFile.Length) bytes)"
    }
}
[void]$sb.AppendLine("| **P1: Trace** | Log Generation | $traceStatus | $traceEvid |")

# P3: Stability
$crashFile = "$logDir\crash.log"
$crashStatus = "NO"
$crashEvid = "Clean"
if (Test-Path $crashFile) {
    $cItem = Get-Item $crashFile
    if ($cItem.Length -gt 0) {
        $crashStatus = "YES (CRITICAL)"
        $crashEvid = "Size: $($cItem.Length) bytes"
    }
}
[void]$sb.AppendLine("| **P3: Stability** | Crash Detected | $crashStatus | $crashEvid |")

# EOD Safety
# Check trade log or console log for EOD trigger. Hard to grep console log here reliably if not saved.
# We check trade_log for EOD sell? Or just leave it for manual check.
[void]$sb.AppendLine("| **EOD Safety** | Force Close | [Verify] | Check Logs |")

# 2. Performance Summary
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## 2. Performance Summary")

$tradeLog = Get-ChildItem "$logDir\trade_log_*.csv" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
$tradeCount = 0
$winRate = 0
$pnl = 0

if ($tradeLog) {
    $trades = Import-Csv $tradeLog.FullName
    $tradeCount = $trades.Count
    # Calculate PnL if columns exist (assuming 'realized_pnl')
    # For now, just count
}

[void]$sb.AppendLine("- **Total Trades:** $tradeCount")
# [void]$sb.AppendLine("- **Win Rate:** N/A")
# [void]$sb.AppendLine("- **PnL:** N/A")

# 3. Diagnosis
[void]$sb.AppendLine("")
[void]$sb.AppendLine("## 3. Zero-Trade Diagnosis")

if ($traceFile) {
    # Extract 09:20~10:00
    try {
        $first = Import-Csv $traceFile.FullName | Select-Object -First 1
        if ($first) {
            $dt0 = [datetime]$first.ts
            $start = Get-Date ($dt0.ToString("yyyy-MM-dd") + " 09:20:00")
            $end = Get-Date ($dt0.ToString("yyyy-MM-dd") + " 10:00:00")
            
            $reasons = Import-Csv $traceFile.FullName | ForEach-Object { $_.ts = [datetime]$_.ts; $_ } | 
            Where-Object { $_.ts -ge $start -and $_.ts -lt $end } |
            Group-Object reason | Sort-Object Count -Descending | Select-Object -First 3
            
            $domReason = "None"
            if ($reasons) { $domReason = $reasons[0].Name }
            
            [void]$sb.AppendLine("- **Dominant Reason (09:20~10:00):** $domReason")
            
            # Judgment logic
            if ($domReason -match "NO_MA60") {
                [void]$sb.AppendLine("- **Judgment:** FAIL (Operational Defect)")
            }
            elseif ($domReason -match "FEAT_FAIL") {
                [void]$sb.AppendLine("- **Judgment:** WARNING (Check Feeder)")
            }
            else {
                [void]$sb.AppendLine("- **Judgment:** PASS (Market Condition)")
            }
        }
    }
    catch {
        [void]$sb.AppendLine("- **Diagnosis Error:** $($_.Exception.Message)")
    }
}
else {
    [void]$sb.AppendLine("- **Trace File:** Not Found")
}

# Output
$sb.ToString() | Out-File $outputFile -Encoding UTF8
Write-Host "Report generated: $outputFile"
Start-Process $outputFile
